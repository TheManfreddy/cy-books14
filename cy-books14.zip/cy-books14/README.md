# cy-books14

Choix de l'outil de développement : IntelliJ IDEA

Nous avons fait le choix d'utiliser IntelliJ IDEA car il s'agit de l'outil de développement avec lequel chacun d'entre nous a appris à coder en Java. Nous étions donc tous déjà familiarisés avec cet outil. De plus, IntelliJ IDEA offre diverses fonctionnalités qui nous apparaissent comme essentielles : une compilation simplifiée, une complétion automatique intelligente et la détection d'erreurs en temps réel.

Choix du serveur et de la base de données : XAMPP/phpMyAdmin

Nous avons choisi d'utiliser XAMPP pour mettre en place notre serveur. Ce choix s'est fait car nous avions tous déjà utilisé XAMPP lors de notre projet en développement web. De plus, nous avons opté pour XAMPP car il permet l'utilisation de phpMyAdmin pour gérer notre base de données MySQL.

Choix de la plateforme logicielle : JavaFX

Nous avons choisi JavaFX pour notre plateforme logicielle. Ce choix s'est fait naturellement car il s'agit de la seule plateforme logicielle que nous avons étudiée en cours de programmation Java, et donc la seule que nous connaissons. De plus, son intégration avec l'écosystème Java et sa richesse de fonctionnalités de l'UI en fait une plateforme adéquate pour notre projet.


