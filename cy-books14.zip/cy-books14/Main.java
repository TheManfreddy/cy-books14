import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Element;

public class Main {
    private static final String API_URL = "https://catalogue.bnf.fr/api/SRU";

    public static void main(String[] args) {
        try {
            // Paramètres de la requête
            String query = "title all \"Les Misérables\""; // Utilisation de l'index supporté "title"
            String encodedQuery = URLEncoder.encode(query, StandardCharsets.UTF_8.toString());
            String fullUrl = String.format("%s?version=1.2&operation=searchRetrieve&query=%s&maximumRecords=10", API_URL, encodedQuery);

            // Créer un client HTTP
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(new URI(fullUrl))
                    .build();

            // Envoyer la requête et obtenir la réponse
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            String xmlResponse = response.body();

            // Afficher la réponse brute pour diagnostic
            /*System.out.println("Raw XML Response:");
            System.out.println(xmlResponse);*/

            // Parser la réponse XML
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(new java.io.ByteArrayInputStream(xmlResponse.getBytes(StandardCharsets.UTF_8)));

            // Traiter les données XML ici (extraction des titres des livres)
            NodeList records = document.getElementsByTagName("mxc:record");
            System.out.println("Number of records found: " + records.getLength());
            int count = 0;

            for (int i = 0; i < records.getLength(); i++) {
                Element record = (Element) records.item(i);
                NodeList datafields = record.getElementsByTagName("mxc:datafield");

                String title = null;
                String author = null;
                String isbn = null;
                boolean isBook = false;

                for (int j = 0; j < datafields.getLength(); j++) {
                    Element datafield = (Element) datafields.item(j);

                    if ("200".equals(datafield.getAttribute("tag"))) {
                        NodeList subfields = datafield.getElementsByTagName("mxc:subfield");
                        for (int k = 0; k < subfields.getLength(); k++) {
                            Element subfield = (Element) subfields.item(k);
                            if ("a".equals(subfield.getAttribute("code"))) {
                                title = subfield.getTextContent();
                            } else if ("f".equals(subfield.getAttribute("code"))) {
                                author = subfield.getTextContent();
                            } else if ("b".equals(subfield.getAttribute("code")) && "Texte imprimé".equals(subfield.getTextContent())) {
                                isBook = true;
                            }
                        }
                    } else if ("010".equals(datafield.getAttribute("tag"))) {
                        NodeList subfields = datafield.getElementsByTagName("mxc:subfield");
                        for (int k = 0; k < subfields.getLength(); k++) {
                            Element subfield = (Element) subfields.item(k);
                            if ("a".equals(subfield.getAttribute("code"))) {
                                isbn = subfield.getTextContent();
                            }
                        }
                    }
                }

                if (isBook && title != null) {
                    System.out.println("Title: " + title);
                    if (author != null) {
                        System.out.println("Author: " + author);
                    } else {
                        System.out.println("Author: Not available");
                    }
                    if (isbn != null) {
                        System.out.println("ISBN: " + isbn);
                    } else {
                        System.out.println("ISBN: Not available");
                    }
                    System.out.println();
                    count++;
                    if (count >= 10) {
                        break;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
