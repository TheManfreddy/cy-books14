import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DatabaseConnection {
    private String userName = "votre_nom_utilisateur";
    private String password = "votre_mot_de_passe";
    private String serverName = "localhost"; // ou l'adresse IP de votre serveur MySQL
    private String portNumber = "3306"; // Le port MySQL par défaut est 3306
    private String dbName = "votre_nom_de_base_de_données";
    private String dbms = "mysql"; // ou "derby" si vous utilisez Derby

    public Connection getConnection() throws SQLException {
        Connection conn = null;
        Properties connectionProps = new Properties();
        connectionProps.put("user", this.userName);
        connectionProps.put("password", this.password);

        if (this.dbms.equals("mysql")) {
            conn = DriverManager.getConnection(
                    "jdbc:" + this.dbms + "://" +
                            this.serverName +
                            ":" + this.portNumber + "/" + this.dbName,
                    connectionProps);
        } else if (this.dbms.equals("derby")) {
            conn = DriverManager.getConnection(
                    "jdbc:" + this.dbms + ":" +
                            this.dbName +
                            ";create=true",
                    connectionProps);
        }
        System.out.println("Connecté à la base de données");
        return conn;
    }
}
